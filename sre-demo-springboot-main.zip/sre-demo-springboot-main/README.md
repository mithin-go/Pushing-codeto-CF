# Demo app for Elastic  APM integration

A sample application using postgresql that could be monitored using elastic apm.



